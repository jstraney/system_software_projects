// standard header files
#ifndef STDH 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define STDH 
#endif

#ifndef VM 
#include "vm.h"
#define VM 
#endif

#ifndef ANALYZER
#include "analyzer.h"
#define ANALYZER
#endif

#ifndef GENERATOR 
#include "generator.h"
#define GENERATOR 
#endif



